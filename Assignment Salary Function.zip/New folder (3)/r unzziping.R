zip_file <- "C:/Users/Varnosafety INT/Downloads/Employee Profile.zip"
dest_dir <- "C:/Users/Varnosafety INT/Downloads/unzipped"
unzip(zip_file, exdir = dest_dir)
